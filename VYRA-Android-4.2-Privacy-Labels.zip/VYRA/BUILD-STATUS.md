# VYRA 4.1.0 — Build status

## Source updates in this package
- Replaced the previous flat V icon with a generated 3D metallic shield / V brand mark. Added 3D wordmark artwork for onboarding and adaptive launcher icons.
- Updated onboarding and dashboard brand areas to use the new 3D logo assets. Existing pages retain their dark glass / gradient / elevation styling and motion.
- Added an opt-in MediaProjection visual-protection foreground service with a native Android consent prompt, persistent notification, and Stop action.
- Added in-memory image classification and an internal signal to the AccessibilityService to leave the current app and show VYRA's block screen after a visual detection.
- Added clear local-only processing behavior: no captured frames are saved to disk or uploaded by this feature.
- Updated app version to 4.1.0.

## Not verified here
- Full Android Gradle compilation / APK assembly. This workspace does not have an Android SDK installation or Gradle executable / wrapper JAR.
- Physical device tests for MediaProjection, Android's consent UI, notification stop action, OEM background behavior, screen rotation, locked / secure windows, model accuracy, battery use, and detection latency.
- A response time of 0.5 seconds cannot be guaranteed; it is only a best-effort target.
- The visual model may misclassify images. It is a filtering aid, not a perfect detector.

## Important Android behavior
- Android requires a new user-approved MediaProjection session for every new capture session on Android 14+. VYRA cannot silently grant this permission or bypass the system prompt.
- Android's system screen-sharing controls can stop capture at any time. VYRA also keeps an ongoing foreground-service notification with a Stop action.
- VYRA Accessibility must remain enabled for the automatic Home action and block screen to run.


## VYRA 4.2.0 UI update
- Replaced the literal keyword text field with neutral labels: Media pattern checks, Gallery and image cues, Context-aware matching, and Local rule processing.
- The default matching phrases in `ProtectionPrefs.defaultKeywords()` and the classifier logic were not modified. Previously saved custom keyword values remain stored and are still read by the classifier.
- Updated app version to 4.2.0.
- Full Gradle build and physical-device UI test are still not verified in this environment.
