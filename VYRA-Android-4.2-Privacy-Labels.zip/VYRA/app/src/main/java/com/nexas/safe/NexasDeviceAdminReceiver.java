package com.nexas.safe;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class NexasDeviceAdminReceiver extends DeviceAdminReceiver {
    @Override public void onEnabled(Context context, Intent intent) {
        Toast.makeText(context, "VYRA Admin enabled", Toast.LENGTH_SHORT).show();
    }
    @Override public CharSequence onDisableRequested(Context context, Intent intent) {
        return "Turning this off reduces uninstall resistance. It does not disable Android's owner recovery controls.";
    }
    @Override public void onDisabled(Context context, Intent intent) {
        Toast.makeText(context, "VYRA Admin disabled", Toast.LENGTH_SHORT).show();
    }
}
