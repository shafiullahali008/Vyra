# Build VYRA 4.0 in GitHub Actions

1. Upload the source archive as `NexasSafe-Android-Source.zip` to the repository root (the workflow watches this exact filename).
2. Copy `VYRA/.github/workflows/android.yml` from the extracted archive into the repository at `.github/workflows/android.yml`, replacing the old workflow.
3. Push to `main` or run **VYRA Android Build** from Actions.
4. Download the `VYRA-debug-APK` artifact after a successful run.

The workflow installs Gradle 8.9 and Android SDK platform / build tools 35. It builds the project in the archive's `VYRA/` directory.
