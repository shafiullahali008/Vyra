# VYRA 4.2.0 — Release notes

- Replaced the visible keyword editor with neutral browsing-safety labels and rule-count status.
- Kept the existing stored default keyword phrases and ContextAwareTextClassifier matching behaviour unchanged.
- Existing saved custom rules remain stored and continue to be consumed by the classifier.
- Updated app version to 4.2.0 (versionCode 16).

The UI no longer displays the literal filtering phrases. The classifier still uses the same defaults defined in ProtectionPrefs.defaultKeywords().
